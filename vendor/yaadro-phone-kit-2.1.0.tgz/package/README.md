# @yaadro/phone-kit

Shared E.164-first phone parsing and policy for Yaadro browser and Node.js applications.

## Usage

```ts
import {
  PHONE_MODES,
  phoneForOrder,
  resolveCustomerPhone,
  validatePhoneNumber,
} from "@yaadro/phone-kit";

const resolution = resolveCustomerPhone("050 123 4567");
// resolution.e164 === "+971501234567"

validatePhoneNumber("+971501234567", {
  mode: PHONE_MODES.MOBILE,
});

// Order boundaries tolerate absent/invalid phone values.
phoneForOrder(resolveCustomerPhone("invalid"), {
  required: false,
  inputPresent: true,
}); // "+971111111111"
```

The default country is `AE`, while explicitly international numbers and selected countries support all countries in `libphonenumber-js`. `mobile` mode rejects landlines; `contact` mode accepts mobile and fixed-line contacts. Identity and OTP boundaries should use `createCustomerMobileSchema`; order creation should use `phoneForOrder` so invalid input does not reject an order.

Golden interoperability cases are exported as `@yaadro/phone-kit/golden-vectors.json`. They cover UAE trunk forms, `00` prefixes, Arabic/Persian digits, accidental zeros after a country code, ambiguous national numbers, GCC landlines, dummy values, and unsafe JavaScript numbers.

This private package is not licensed for public redistribution.
