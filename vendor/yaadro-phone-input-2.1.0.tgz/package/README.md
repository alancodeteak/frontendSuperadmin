# @yaadro/phone-input

Accessible React phone input backed by `@yaadro/phone-kit`.

## Setup

Import the stylesheet once in the application root:

```ts
import "@yaadro/phone-input/styles.css";
```

Then render the controlled component:

```tsx
import { YaadroPhoneInput } from "@yaadro/phone-input";

<YaadroPhoneInput
  aria-label="Customer mobile"
  mode="mobile"
  value={phone}
  onChange={(e164, resolution) => {
    setPhone(e164);
    setPhoneValid(Boolean(resolution.e164));
  }}
/>;
```

The component defaults to the UAE (`AE`) and limits its country selector to
`DEFAULT_PHONE_INFER_COUNTRIES` from `@yaadro/phone-kit` (`AE`, `IN`, `PK`,
`PH`, `BD`, `EG`, `GB`, `US`, `CA`, `SA`, `OM`, `KW`, `BH`, `QA`). Pasted
numbers outside this frontend list are rejected. The component uses a `tel`
input and normalizes pasted international, Arabic-digit, and Persian-digit
values. `mobile` mode rejects fixed lines; `contact` mode accepts mobile and
landline contacts. Supply an `aria-label` or an associated visible label
appropriate to the form.

`PHONE_INPUT_STYLESHEET` contains the stable CSS export path,
`YAADRO_PHONE_INPUT_COUNTRIES` exposes the selector list, and
`resolvePastedPhoneInput` is available for consumers that implement a custom
paste surface.

This private package is not licensed for public redistribution.
